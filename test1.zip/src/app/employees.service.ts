import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class EmployeesService {

  constructor(private http: HttpClient) { }

  getEmp():Observable<any>{
    return this.http.get(environment.empURL)
    .pipe(
      map(result => result)
    );
  }

  getUsers():Observable<any>{
    return this.http.get('users')
    .pipe(
      map(result => result)
    );
  }
}
