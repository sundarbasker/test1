import { Injectable } from "@angular/core";
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from "@angular/common/http";
import { Observable } from "rxjs";
import { tap, finalize } from 'rxjs/operators';
import { LoaderService } from "./loader.service";

@Injectable()

export class CustomeHttpInterceptor implements HttpInterceptor {
constructor(public loaderService: LoaderService){}
    intercept(req: HttpRequest<any>, next: HttpHandler): 
    Observable<HttpEvent<any>> {


        console.log('Interceptor', req);
        const newReq = req.clone({url: "https://jsonplaceholder.typicode.com/" + req.url,
        headers:req.headers.set('Autherization', 'Testing Headers')})
        return next.handle(newReq)

        .pipe(
            tap((result)=>{
                console.log('Success', result)
            },
            (error) =>{
                console.log('error', error)
            }
            )
        )
        
    }

}