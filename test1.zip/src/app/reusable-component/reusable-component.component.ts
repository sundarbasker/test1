import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-reusable-component',
  templateUrl: './reusable-component.component.html',
  styleUrls: ['./reusable-component.component.scss']
})
export class ReusableComponentComponent implements OnInit {
@Input() item={name:'', email:'', mobile:''}
  constructor() { }

  ngOnInit(): void {
  }

}
