import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})
export class AppHighlightDirective {
  @Input() appHighlight ='';

  constructor(private eleRef: ElementRef) {
    eleRef.nativeElement.style.color = 'red';
    eleRef.nativeElement.style.border = '1px solid red';
   }

   @HostListener('mouseenter') onMouseEnter(){
    this.highlight(this.appHighlight);
   }
   @HostListener("mouseleave") onMouseLeave() {
    this.highlight("");
  }
  private highlight(color: string) {
    this.eleRef.nativeElement.style.color = color;
  }

}
