import { Component, OnInit } from '@angular/core';
import { EmployeesService } from '../employees.service';
import { LoaderService } from '../loader.service';
import { map } from 'rxjs';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.scss']
})
export class EmployeeComponent implements OnInit {
  employee:any;
  p: number = 1;
  count: number = 10;

  users:any;
  
  
  
  constructor(private empService: EmployeesService, public loaderService: LoaderService) { }


  ngOnInit(): void {
   
    setTimeout(() =>{
      this.empService.getUsers()
    //  .pipe(map(users => users.filter((users: { id: number; }) => users.id > 5)))
      .subscribe(data=>{
        this.users = data;
      })
    }, 3000);

    
    // this.empService.getEmp().subscribe(data=>{
    //   this.employee = data;
    //  // console.log('Employee', this.employee)
    // })

 
  }



}
