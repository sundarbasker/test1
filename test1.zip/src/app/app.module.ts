import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { NgxPaginationModule } from 'ngx-pagination';
import { ReactiveFormsModule } from '@angular/forms';
import { AppendPipe } from './custom.pipe';

import { MatRadioModule } from '@angular/material/radio';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
//import {MatPaginator} from '@angular/material/paginator';
//import {MatTableDataSource} from '@angular/material/table';



import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
//import { ProductComponent } from './product/product.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './parent/child/child.component';
import { EmployeeComponent } from './employee/employee.component';
import { RegistrationComponent } from './registration/registration.component';
import { CommonComponent } from './common/common.component';
import { LoginComponent } from './login/login.component';
import { FormarrayComponent } from './formarray/formarray.component';

import { ReusableComponentComponent } from './reusable-component/reusable-component.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppHighlightDirective } from './app-highlight.directive';

import { CustomeHttpInterceptor } from './http.interceptor';
import { InterceptorService } from './interceptor.service';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AboutComponent,
    
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    ParentComponent,
    ChildComponent,
    EmployeeComponent,
    CommonComponent,
    ReusableComponentComponent,
    RegistrationComponent,
    FormarrayComponent,
    AppHighlightDirective,
    AppendPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    HttpClientModule,
    NgxPaginationModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatRadioModule,
    MatCardModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressBarModule,
    MatProgressSpinnerModule
    //MatPaginator
   // MatTableDataSource
    
  ],
  providers: [{provide: HTTP_INTERCEPTORS, useClass: CustomeHttpInterceptor, multi: true},
  {provide:HTTP_INTERCEPTORS, useClass: InterceptorService, multi: true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
