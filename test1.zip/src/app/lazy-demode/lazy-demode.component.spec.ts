import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LazyDemodeComponent } from './lazy-demode.component';

describe('LazyDemodeComponent', () => {
  let component: LazyDemodeComponent;
  let fixture: ComponentFixture<LazyDemodeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LazyDemodeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LazyDemodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
