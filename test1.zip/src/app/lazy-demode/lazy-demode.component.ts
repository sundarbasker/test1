import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lazy-demode',
  templateUrl: './lazy-demode.component.html',
  styleUrls: ['./lazy-demode.component.scss']
})
export class LazyDemodeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
