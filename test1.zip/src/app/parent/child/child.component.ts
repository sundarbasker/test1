import { Component, OnInit,EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss']
})
export class ChildComponent implements OnInit {

@Input() messageToChild:string='';
@Output() childEvent = new EventEmitter();
  constructor() { }


  ngOnInit(): void {
  }
  clickToSend(){
    //alert('test')
    this.childEvent.emit("Hi i'm from child");
  }
  
}
