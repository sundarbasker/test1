import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.scss']
})
export class ParentComponent implements OnInit {
  // public message:any;
  receivedMessage: any;
  parentMessage: string = '';
  constructor() { }

  receiveMessage(event:any){
    this.receivedMessage = event;
  }

  ngOnInit(): void {
this.parentMessage = "Message from parent component"
  }

}
