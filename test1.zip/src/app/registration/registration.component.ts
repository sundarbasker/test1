import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';  

// import custom validator to validate that password and confirm password fields match
// import { MustMatch } from './_helpers/must-match.validator';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {

  registerForm:any= FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder) { }

  // profileForm = this.formBuilder.group({
  //   firstName: [''],
  //   lastName: [''],
  //   address: [''],
  //   dob: [''],
  //   gender: ['']
  // });

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.compose([Validators.required,
        Validators.minLength(3),//,Validators.maxLength(8),
        Validators.pattern("^[0-9]*$")])],
      
      confirmPassword: ['', Validators.required],
     
        //validator: MustMatch('newPassword', 'confirmPassword'),
   
        //skills: ['', Validators.required],
      skills: new FormArray([
        new FormControl('', Validators.required)
      ])
  }, {
     // validator: MustMatch('password', 'confirmPassword')
  });
  }
  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }

  onSubmit() {
      this.submitted = true;

      // stop here if form is invalid
      if (this.registerForm.invalid) {
          return;
      }

      alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value))
  }


  // private createSkillsFormGroup(): FormGroup {
  //   return new FormGroup({
  //     'Skills': new FormControl('', Validators.required),
  //     'Skill': new FormControl('')
  //   })
  // }

  addSkills(){
  //   console.log('new form control', new FormControl(null, Validators.required));
  //  this.registerForm.get('skills').push(this.createSkillsFormGroup);

   console.log('new form control', new FormControl(null, Validators.required));
   this.registerForm.get('skills').push(new FormControl('', Validators.required));
   this.registerForm.get('skills1').push(new FormControl('', Validators.required));
   this.registerForm.get('skills2').push(new FormControl('', Validators.required));
   
  }

  delSkills(i: number){
    const skills = this.registerForm.get('skills') as FormArray

    if(skills.length > 1){
      skills.removeAt(i)
    }
    else {
      skills.reset()
    }
  }
  // delSkills1(i: number) {
  //   const skills = this.registerForm.get('skills') as FormArray
  //   if (skills.length > 1) {
  //     skills.removeAt(i)
  //   } else {
  //     skills.reset()
  //   }
  // }

  // delSkills1(i:any){
  //   const delcontrol = this.registerForm.get('skills') as FormArray;
  //   if (this.registerForm.length > 1) {
  //     delcontrol.removeAt(i);
  //   }
  
  //  }

   
  // deleteTripRow(index) {
  //   const control = this.leaveRetunTripRows;
  //   if (this.leaveRetunTripRows.length > 1) {
  //     control.removeAt(index);
  //   }
  //   else {
  //     this.leaveRetunTripRows.controls = [];
  //     this.timesFormRows.setControl('leaveReturn02', this.fb.array([this.createLeaveReturnForm()]));
  //   }
  // }

}
