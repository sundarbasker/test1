import { Component, OnInit, VERSION } from '@angular/core';
import { FormControl, FormGroup, FormArray, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-formarray',
  templateUrl: './formarray.component.html',
  styleUrls: ['./formarray.component.scss']
})
export class FormarrayComponent implements OnInit {

  //name = 'Angular ' + VERSION.major;
  name:any;
  PTWform: FormGroup;
  EditFormArray!: FormGroup;

  viewEditTimecardFormD = [
    {leave: 'XXX', return: 'ZZZ'},
    {leave: 'AAA', return: 'BBB'}
]
  data = [
    { name: 'dev', label: 'actor' },
    { name: 'madhu', label: 'actress' },
  ];

  getFormArryData() {
    console.log(this.data);
  }
  constructor(private fb: FormBuilder) {
    this.PTWform = this.fb.group({
    //  id: '12',
      EditFormArray: this.fb.array([]),
    });

    this.EditFormArray = this.fb.group({
      EditFormArray: this.fb.array([])
    })
  }
  ngOnInit(): void {
    //this.getFormArryData();
    this.PTWform = this.fb.group({
      EditFormArray: this.fb.array(this.getData()),
    });

    // this.EditFormArray = this.fb.group({
    //   leaveReturn02: this.fb.array(this.lrData())
    // })
  }
  get viewEditTimecardForm() { return this.PTWform.controls['EditFormArray'] as FormArray; }

  addCreds() {
    const creds = this.viewEditTimecardForm;
    creds.push(
      this.fb.group({
        name: '',
        label: '',
      })
    );
  }

  getData(): FormGroup[] {
    return this.data.map((d) =>
      this.fb.group({
        name: d.name,
        label: d.label,
      })
    );
  }
  
// createPTWForm(){  
//   leaveReturn02: this.fb.array([this.createLeaveReturnForm()])
// }

// get viewEditTimecardForm() { return this.EditFormArray.get('leaveReturn02') as FormArray; }

// createLeaveReturnForm(): FormGroup {
//   return this.fb.group({
//     leave: [''],
//     return: ['']
//   })
// }




// addTripRow(i:any) {
//   if (this.viewEditTimecardForm.length < 5) {
//     this.viewEditTimecardForm.push(this.createLeaveReturnForm());
//   }
// }
// addVehicleRow(i:any) {
//   if (this.viewEditTimecardForm.length < 5) {
//     this.viewEditTimecardForm.insert(i + 1, this.createLeaveReturnForm());
//   }
// }

 


  // lrData(): FormGroup[] {
  //   return this.viewEditTimecardFormD.map((d) =>
  //     this.fb.group({
  //       leave: d.leave,
  //       return: d.return,
  //     })
  //   );
  // }
}
