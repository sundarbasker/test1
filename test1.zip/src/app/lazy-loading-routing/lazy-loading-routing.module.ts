import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule, Routes} from '@angular/router';  
import { LazyDemodeComponent } from '../lazy-demode/lazy-demode.component';


const routes: Routes = [
  { path: '', component: LazyDemodeComponent }
 ]; 

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)],
    exports: [RouterModule] 
    
})
export class LazyLoadingRoutingModule { }
