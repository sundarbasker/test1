import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss']
})
export class AboutComponent implements OnInit {
  empList=[
    {name:'Smith', email:'smith@gmail.com', mobile: '99999886688'},
    {name:'William', email:'Peter@gmail.com', mobile: '9889989988'},
    {name:'Peter John', email:'John@gmail.com', mobile: '9555986666'}
  ]

  constructor() { }

  ngOnInit(): void {
  }

}
