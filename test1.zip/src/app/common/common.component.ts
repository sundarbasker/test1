import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common',
  templateUrl: './common.component.html',
  styleUrls: ['./common.component.scss']
})
export class CommonComponent implements OnInit {

  day = new Date();
  num = 2354.54656;
  status:string='error';

  getColor() {
    return 'yellow';
  }
  
  arrBirds: any [] = [
    { name: 'Bells Sparrow' },
    { name: 'Mourning Dove'},
    { name: 'Bald Eagle' }
  ];
  
  orderTypes = {
    id: 1,
    orders: [  
      {
        id: 1,
        orderType: "XYZ"
      },
      {
        id: 2,
        orderType: "ABC"
      },
      {
        id: 3,
        orderType: "ZXC"
      }
    ],

    name: [  
      {
        id: 1,
        orderType: "Smith"
      },
      {
        id: 2,
        orderType: "John"
      },
      {
        id: 3,
        orderType: "Williams"
      }
    ]
  };

  print(){
    window.print();
  }
  constructor() { }

  ngOnInit(): void {
  }

}
