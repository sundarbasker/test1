import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LazyLoadingRoutingModule } from './lazy-loading-routing/lazy-loading-routing.module';


import { AboutComponent } from './about/about.component';
import { ProductComponent } from './product/product.component';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './parent/child/child.component';
import { EmployeeComponent } from './employee/employee.component';
import { CommonComponent } from './common/common.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { registerLocaleData } from '@angular/common';
import { FormarrayComponent } from './formarray/formarray.component';

const routes: Routes = [
  {path:'', component: LoginComponent},
  { path:'home', component: HomeComponent},
  { path: 'lazy-loading',
  loadChildren: () =>   
 import('./lazy-loading-routing/lazy-loading-routing.module')
  .then(m => m.LazyLoadingRoutingModule)},
  { path: 'login', component: LoginComponent},
  { path:'about', component: AboutComponent },
  { path: 'product', component: ProductComponent},
  { path: 'parent', component: ParentComponent},
  { path: 'child', component: ChildComponent},
  { path: 'employees', component: EmployeeComponent},
  { path: 'registration', component: RegistrationComponent},
  { path: 'common', component: CommonComponent},
  { path: 'formarray', component: FormarrayComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
