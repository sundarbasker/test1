import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  email:any;
   password: any;
   loginForm:any =  FormGroup;
  constructor(private authService : AuthService, private router : Router) {
  }

  
  ngOnInit(): void {

    this.loginForm = new FormGroup({
      email: new FormControl(null, Validators.required),
      password: new FormControl("admin"),
   });
   
  }
  onSubmit(){
    if(this.email == null){
      alert('test');
    this.router.navigate(['/about']);
    console.log('username' + this.email);
    }
    else{
      this.router.navigate(['/login']);
    }
    
  }

}
