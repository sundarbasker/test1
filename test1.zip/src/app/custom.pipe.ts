import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
    name: 'append'
})

export class AppendPipe implements PipeTransform {
    transform(value:any, appendText:any) {
        return value + appendText
    }
}